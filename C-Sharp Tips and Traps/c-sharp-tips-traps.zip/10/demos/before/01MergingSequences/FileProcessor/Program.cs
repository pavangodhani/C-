﻿using System;
using System.Collections.Generic;
using static System.Console;

namespace FileProcessor
{
    class Program
    {
        static void Main(string[] args)
        {
            JoinNamesAndAges();

            SetOperations();

            WriteLine("Press enter to exit");
            ReadLine();
        }



        private static void JoinNamesAndAges()
        {

        }

        private static List<string> Join(string[] names, string[] ages)
        {
            return new List<string>();
        }

        private static List<string> JoinV2(string[] names, string[] ages)
        {
            return new List<string>();
        }


        private static List<(string name, string age)> JoinV3(string[] names, string[] ages)
        {
            return new List<(string name, string age)>();
        }


        private static void SetOperations()
        {

        }
    }
}
