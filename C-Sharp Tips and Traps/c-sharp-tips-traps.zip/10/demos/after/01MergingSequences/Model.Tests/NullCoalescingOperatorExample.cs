﻿using Xunit;

namespace Model.Tests
{    
    public class NullCoalescingOperatorExample
    {
        [Fact]
        public void NoNullCoalescingOperator()
        {

        }

        [Fact]
        public void NullCoalescingOperator()
        {

        }

        [Fact]
        public void NullCoalescingOperatorAndNullConditional()
        {

        }

        [Fact]
        public void NullableValueTypes()
        {

        }

        [Fact]
        public void Chaining()
        {

        }
    }
}