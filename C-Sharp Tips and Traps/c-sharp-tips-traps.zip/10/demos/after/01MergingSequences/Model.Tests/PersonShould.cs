﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Xunit;

namespace Model.Tests
{
   
    public class PersonShould
    {
        [Fact]
        public void NotifyWhenNameChanged()
        {
               
        }


        [Fact]
        public void NotifyWhenAgeChanged()
        {

        }

        [Fact]
        public void OtherExamples()
        {

        }

    }
}
