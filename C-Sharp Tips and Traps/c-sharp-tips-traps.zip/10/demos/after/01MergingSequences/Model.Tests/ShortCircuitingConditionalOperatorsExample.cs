﻿using Xunit;

namespace Model.Tests
{
    public class ShortCircuitingConditionalOperatorsExample
    {

        [Fact]
        public void NonShortCircuit()
        {

        }
    }
}