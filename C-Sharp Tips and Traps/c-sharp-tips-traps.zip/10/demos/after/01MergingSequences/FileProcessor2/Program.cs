﻿using System;
using static System.Console;

namespace FileProcessor2
{
    class Program
    {
        static void Main(string[] args)
        {

            

            WriteLine();
            WriteLine("Press enter to exit");
            ReadLine();
        }
    }
}
