﻿namespace ConsoleApp
{
    class Person
    {
        public string Name { get; set; }
    }
}
