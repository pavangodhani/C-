﻿namespace ClassLibrary.StructPerformance
{
    public struct WithRefNoOverride
    {
        public int X { get; set; }
        public int Y { get; set; }
        public string Description { get; set; }
    }
}
