﻿namespace ClassLibrary.StructPerformance
{
    public struct NoRefNoOverride
    {
        public int X { get; set; }
        public int Y { get; set; }
    }
}
