﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExtensionMethods.Tests
{
    public class StringList : List<string>
    {
    }
}
