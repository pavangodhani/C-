﻿using System;
using ExtensionMethods.Contracts;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine($"Starting: {DateTime.Now.ToUnixSeconds()}");
            Console.ReadLine();
        }
    }
}
