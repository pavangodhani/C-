﻿namespace Org.Messaging
{
    public class Envelope
    {
        public string Subject { get; set; }

        public byte[] Body { get; set; }
    }
}
