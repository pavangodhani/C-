﻿namespace Org.Messaging
{
    public interface IMessage
    {
    }
}
