﻿using NUnit.Framework;
using System.Linq;

namespace PeopleViewer.Test
{
    public class PeopleViewModelTest
    {

    }
}
